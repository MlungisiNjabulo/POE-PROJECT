﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Part2
{
    // Define a delegate for calculating total calories
    public delegate double CalculateCaloriesHandler(List<Ingredient> ingredients);

    // Define a delegate for handling recipes exceeding calorie limits
    public delegate void ExceedsCaloriesHandler(object sender, string recipeName);

    // Class for ingredients
    public class Ingredient
    {
        // These are the details for the ingredients and their descriptions 
        public string Name { get; set; }
        public double Quantity { get; set; }
        public string Units { get; set; }
        public int Calories { get; set; }
        public string FoodGroup { get; set; }
    }

    // Class for steps
    public class Step
    {
        public string Description { get; set; }
    }

    // Class for recipe 
    public class Recipe
    {
        public string Name { get; set; }
        private List<Ingredient> ingredients;
        private List<Step> steps;

        // Event for when recipe exceeds calories
        public event ExceedsCaloriesHandler RecipeExceedsCalories;

        // Delegate for calculating total calories
        public CalculateCaloriesHandler CalculateCalories;

        public Recipe()
        {
            ingredients = new List<Ingredient>();
            steps = new List<Step>();
            // Set the default delegate method for calculating calories
            CalculateCalories = DefaultCalculateTotalCalories;
        }

        public void AddIngredient(string name, double quantity, string units, int calories, string foodGroup)
        {
            ingredients.Add(new Ingredient
            {
                Name = name,
                Quantity = quantity,
                Units = units,
                Calories = calories,
                FoodGroup = foodGroup
            });
        }

        public void AddStep(string description)
        {
            steps.Add(new Step { Description = description });
        }

        //  method for calculating total calories
        private double DefaultCalculateTotalCalories(List<Ingredient> ingredients)
        {
            return ingredients.Sum(i => i.Calories * i.Quantity);
        }

        public void DisplayRecipe()
        {
            Console.WriteLine($"Recipe: {Name}");
            Console.WriteLine("Ingredients: ");
            foreach (var ingredient in ingredients)
            {
                Console.WriteLine($"{ingredient.Quantity} {ingredient.Units} of {ingredient.Name}");
            }
            Console.WriteLine("Steps: ");
            for (int i = 0; i < steps.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {steps[i].Description}");
            }
            Console.WriteLine($"Total Amount of Calories: {CalculateCalories(ingredients)}");
        }

        public void NotifyIfExceedsCalories()
        {
            if (CalculateCalories(ingredients) > 300)
            {
                RecipeExceedsCalories?.Invoke(this, Name);
            }
        }
    }

    // Class for Recipe Collections
    public class RecipeCollection
    {
        private List<Recipe> recipes;

        public RecipeCollection()
        {
            recipes = new List<Recipe>();
        }

        public void AddRecipe(Recipe recipe)
        {
            recipes.Add(recipe);
        }

        public void DisplayRecipes()
        {
            var sortedRecipes = recipes.OrderBy(r => r.Name);
            Console.WriteLine("Recipes:");
            foreach (var recipe in sortedRecipes)
            {
                Console.WriteLine(recipe.Name);
            }
        }

        public Recipe GetRecipeByName(string name)
        {
            return recipes.FirstOrDefault(r => r.Name.Equals(name, StringComparison.OrdinalIgnoreCase));
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            RecipeCollection recipeCollection = new RecipeCollection();
            while (true)
            {
                Console.WriteLine("Choose an option: ");
                Console.WriteLine("1. Enter new recipe");
                Console.WriteLine("2. Display all recipes");
                Console.WriteLine("3. Display a recipe");
                Console.WriteLine("4. Exit");

                if (!int.TryParse(Console.ReadLine(), out int option))
                {
                    Console.WriteLine("Invalid input. Try again.");
                    continue;
                }

                switch (option)
                {
                    case 1:
                        try
                        {
                            Recipe newRecipe = EnterRecipeDetails();
                            recipeCollection.AddRecipe(newRecipe);
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine($"An error occurred: {ex.Message}");
                        }
                        break;
                    case 2:
                        recipeCollection.DisplayRecipes();
                        break;
                    case 3:
                        Console.WriteLine("Enter the name of the recipe to display: ");
                        string recipeName = Console.ReadLine();
                        Recipe recipeToDisplay = recipeCollection.GetRecipeByName(recipeName);

                        if (recipeToDisplay != null)
                        {
                            recipeToDisplay.DisplayRecipe();
                        }
                        else
                        {
                            Console.WriteLine("Recipe couldn't be found.");
                        }
                        break;
                    case 4:
                        Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("Invalid input. Try again.");
                        break;
                }
            }
        }

        static Recipe EnterRecipeDetails()
        {
            Recipe recipe = new Recipe();
            Console.WriteLine("Enter the name of your recipe: ");
            recipe.Name = Console.ReadLine();

            Console.WriteLine("Enter the number of ingredients:");
            if (!int.TryParse(Console.ReadLine(), out int ingredientCount))
            {
                throw new ArgumentException("Invalid input for number of ingredients.");
            }

            for (int i = 0; i < ingredientCount; i++)
            {
                Console.WriteLine($"Ingredient details #{i + 1}: ");
                Console.Write("Name: ");
                string ingredientName = Console.ReadLine();
                Console.Write("Quantity: ");
                if (!double.TryParse(Console.ReadLine(), out double quantity))
                {
                    throw new ArgumentException("Invalid input for quantity.");
                }
                Console.Write("Units: ");
                string units = Console.ReadLine();
                Console.Write("Calories: ");
                if (!int.TryParse(Console.ReadLine(), out int calories))
                {
                    throw new ArgumentException("Invalid input for calories.");
                }
                Console.Write("Food Group: ");
                string foodGroup = Console.ReadLine();
                recipe.AddIngredient(ingredientName, quantity, units, calories, foodGroup);
            }

            Console.WriteLine("Enter the number of steps: ");
            if (!int.TryParse(Console.ReadLine(), out int stepCount))
            {
                throw new ArgumentException("Invalid input for number of steps.");
            }

            for (int i = 0; i < stepCount; i++)
            {
                Console.WriteLine($"Step #{i + 1}: ");
                string description = Console.ReadLine();
                recipe.AddStep(description);
            }

            recipe.RecipeExceedsCalories += RecipeExceedsCaloriesHandler;
            recipe.NotifyIfExceedsCalories();

            return recipe;
        }

        static void RecipeExceedsCaloriesHandler(object sender, string recipeName)
        {
            Console.WriteLine($"Warning: Recipe '{recipeName}' is over 300 calories.");
        }
    }
}
