﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;


namespace RecipeManager

{
    public partial class MainWindow : Window
    {
        private RecipeCollection recipeCollection;

        public MainWindow()
        {
            InitializeComponent();
            recipeCollection = new RecipeCollection();
        }

        private void AddRecipeButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Recipe newRecipe = new Recipe
                {
                    Name = RecipeNameTextBox.Text
                };

                var ingredients = IngredientTextBox.Text.Split('\n');
                foreach (var ingredient in ingredients)
                {
                    var parts = ingredient.Split(',');
                    newRecipe.AddIngredient(parts[0].Trim(), double.Parse(parts[1].Trim()), parts[2].Trim(), int.Parse(parts[3].Trim()), parts[4].Trim());
                }

                var steps = StepsTextBox.Text.Split('\n');
                foreach (var step in steps)
                {
                    newRecipe.AddStep(step.Trim());
                }

                newRecipe.RecipeExceedsCalories += RecipeExceedsCaloriesHandler;
                newRecipe.NotifyIfExceedsCalories();
                recipeCollection.AddRecipe(newRecipe);

                MessageBox.Show("Recipe added successfully!");
                RecipeNameTextBox.Clear();
                IngredientTextBox.Clear();
                StepsTextBox.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error adding recipe: {ex.Message}");
            }
        }

        private void DisplayRecipesButton_Click(object sender, RoutedEventArgs e)
        {
            RecipeListBox.Items.Clear();
            var sortedRecipes = recipeCollection.GetRecipes().OrderBy(r => r.Name);
            foreach (var recipe in sortedRecipes)
            {
                RecipeListBox.Items.Add(recipe.Name);
            }
        }

        private void DisplayPieChartButton_Click(object sender, RoutedEventArgs e)
        {
            var selectedRecipes = RecipeListBox.SelectedItems.Cast<string>().Select(name => recipeCollection.GetRecipeByName(name)).ToList();
            if (selectedRecipes.Count == 0)
            {
                MessageBox.Show("Please select at least one recipe.");
                return;
            }

            var foodGroupTotals = new Dictionary<string, double>();

            foreach (var recipe in selectedRecipes)
            {
                foreach (var ingredient in recipe.GetIngredients())
                {
                    if (foodGroupTotals.ContainsKey(ingredient.FoodGroup))
                    {
                        foodGroupTotals[ingredient.FoodGroup] += ingredient.Quantity;
                    }
                    else
                    {
                        foodGroupTotals[ingredient.FoodGroup] = ingredient.Quantity;
                    }
                }
            }

            DisplayPieChart(foodGroupTotals);
        }

        private void DisplayPieChart(Dictionary<string, double> foodGroupTotals)
        {
            var total = foodGroupTotals.Values.Sum();
            var pieChartWindow = new Window
            {
                Title = "Pie Chart",
                Width = 400,
                Height = 400,
                Content = new Canvas()
            };

            var canvas = (Canvas)pieChartWindow.Content;
            double angle = 0;
            double centerX = 200;
            double centerY = 200;
            double radius = 100;

            foreach (var foodGroup in foodGroupTotals)
            {
                var percentage = foodGroup.Value / total;
                var sliceAngle = percentage * 360;

                var pathFigure = new PathFigure
                {
                    StartPoint = new Point(centerX, centerY)
                };

                var arcSegment = new ArcSegment
                {
                    Point = new Point(centerX + radius * Math.Cos((angle + sliceAngle) * Math.PI / 180), centerY + radius * Math.Sin((angle + sliceAngle) * Math.PI / 180)),
                    Size = new Size(radius, radius),
                    SweepDirection = SweepDirection.Clockwise,
                    IsLargeArc = sliceAngle > 180
                };

                var pathSegmentCollection = new PathSegmentCollection { arcSegment, new LineSegment(new Point(centerX, centerY), true) };
                var pathFigureCollection = new PathFigureCollection { pathFigure };
                pathFigure.Segments = pathSegmentCollection;

                var pathGeometry = new PathGeometry { Figures = pathFigureCollection };
                var path = new Path
                {
                    Fill = new SolidColorBrush(RandomColor()),
                    Data = pathGeometry
                };

                canvas.Children.Add(path);
                angle += sliceAngle;
            }

            pieChartWindow.ShowDialog();
        }

        private Color RandomColor()
        {
            Random random = new Random();
            return Color.FromRgb((byte)random.Next(256), (byte)random.Next(256), (byte)random.Next(256));
        }

        private void RecipeExceedsCaloriesHandler(object sender, string recipeName)
        {
            MessageBox.Show($"Warning: Recipe '{recipeName}' is over 300 calories.");
        }
    }
}
