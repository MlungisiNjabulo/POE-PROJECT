﻿namespace RecipeManager
{
    internal class RecipeCollection
    {
    }
}