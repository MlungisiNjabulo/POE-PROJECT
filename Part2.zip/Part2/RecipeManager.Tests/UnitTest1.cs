using NUnit.Framework;
using Part2;
using System.Collections.Generic;

namespace RecipeManager.Tests
{
    [TestFixture]
    public class RecipeTests
    {
        [Test]
        public void AddIngredient_ShouldAddIngredientToList()
        {
            // Arrange
            var recipe = new Recipe();
            var ingredientName = "Sugar";
            var quantity = 2.0;
            var units = "cups";
            var calories = 200;
            var foodGroup = "Carbs";

            // Act
            recipe.AddIngredient(ingredientName, quantity, units, calories, foodGroup);

            // Assert
            var ingredients = recipe.GetType().GetField("ingredients", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance).GetValue(recipe) as List<Ingredient>;
            Assert.IsNotNull(ingredients);
            Assert.AreEqual(1, ingredients.Count);
            Assert.AreEqual(ingredientName, ingredients[0].Name);
        }

        [Test]
        public void AddStep_ShouldAddStepToList()
        {
            // Arrange
            var recipe = new Recipe();
            var description = "Mix ingredients";

            // Act
            recipe.AddStep(description);

            // Assert
            var steps = recipe.GetType().GetField("steps", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance).GetValue(recipe) as List<Step>;
            Assert.IsNotNull(steps);
            Assert.AreEqual(1, steps.Count);
            Assert.AreEqual(description, steps[0].Description);
        }

        [Test]
        public void CalculateTotalCalories_ShouldReturnCorrectCalories()
        {
            // Arrange
            var recipe = new Recipe();
            recipe.AddIngredient("Sugar", 2.0, "cups", 200, "Carbs");
            recipe.AddIngredient("Flour", 1.0, "cup", 100, "Carbs");

            // Act
            var totalCalories = recipe.CalculateCalories(new List<Ingredient>(recipe.GetType().GetField("ingredients", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance).GetValue(recipe) as List<Ingredient>));

            // Assert
            Assert.AreEqual(500, totalCalories);
        }

        [Test]
        public void NotifyIfExceedsCalories_ShouldTriggerEvent()
        {
            // Arrange
            var recipe = new Recipe();
            recipe.AddIngredient("Sugar", 2.0, "cups", 200, "Carbs");
            recipe.AddIngredient("Flour", 1.0, "cup", 100, "Carbs");

            var eventTriggered = false;
            recipe.RecipeExceedsCalories += (sender, name) => eventTriggered = true;

            // Act
            recipe.NotifyIfExceedsCalories();

            // Assert
            Assert.IsTrue(eventTriggered);
        }

        [Test]
        public void GetRecipeByName_ShouldReturnCorrectRecipe()
        {
            // Arrange
            var collection = new RecipeCollection();
            var recipe1 = new Recipe { Name = "Cake" };
            var recipe2 = new Recipe { Name = "Pie" };
            collection.AddRecipe(recipe1);
            collection.AddRecipe(recipe2);

            // Act
            var retrievedRecipe = collection.GetRecipeByName("Pie");

            // Assert
            Assert.IsNotNull(retrievedRecipe);
            Assert.AreEqual("Pie", retrievedRecipe.Name);
        }
    }
}
